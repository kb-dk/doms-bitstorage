
package dk.statsbiblioteket.doms.domsutil.surveyable;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.domsutil.surveyable package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _StatusMessage_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "statusMessage");
    private final static QName _GetStatusSinceResponse_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "getStatusSinceResponse");
    private final static QName _Severity_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "severity");
    private final static QName _Status_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "status");
    private final static QName _GetStatusResponse_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "getStatusResponse");
    private final static QName _GetStatusSince_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "getStatusSince");
    private final static QName _GetStatus_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "getStatus");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.domsutil.surveyable
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetStatusResponse }
     * 
     */
    public GetStatusResponse createGetStatusResponse() {
        return new GetStatusResponse();
    }

    /**
     * Create an instance of {@link GetStatus }
     * 
     */
    public GetStatus createGetStatus() {
        return new GetStatus();
    }

    /**
     * Create an instance of {@link GetStatusSinceResponse }
     * 
     */
    public GetStatusSinceResponse createGetStatusSinceResponse() {
        return new GetStatusSinceResponse();
    }

    /**
     * Create an instance of {@link Status }
     * 
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link GetStatusSince }
     * 
     */
    public GetStatusSince createGetStatusSince() {
        return new GetStatusSince();
    }

    /**
     * Create an instance of {@link StatusMessage }
     * 
     */
    public StatusMessage createStatusMessage() {
        return new StatusMessage();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "statusMessage")
    public JAXBElement<StatusMessage> createStatusMessage(StatusMessage value) {
        return new JAXBElement<StatusMessage>(_StatusMessage_QNAME, StatusMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatusSinceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "getStatusSinceResponse")
    public JAXBElement<GetStatusSinceResponse> createGetStatusSinceResponse(GetStatusSinceResponse value) {
        return new JAXBElement<GetStatusSinceResponse>(_GetStatusSinceResponse_QNAME, GetStatusSinceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Severity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "severity")
    public JAXBElement<Severity> createSeverity(Severity value) {
        return new JAXBElement<Severity>(_Severity_QNAME, Severity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Status }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "status")
    public JAXBElement<Status> createStatus(Status value) {
        return new JAXBElement<Status>(_Status_QNAME, Status.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "getStatusResponse")
    public JAXBElement<GetStatusResponse> createGetStatusResponse(GetStatusResponse value) {
        return new JAXBElement<GetStatusResponse>(_GetStatusResponse_QNAME, GetStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatusSince }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "getStatusSince")
    public JAXBElement<GetStatusSince> createGetStatusSince(GetStatusSince value) {
        return new JAXBElement<GetStatusSince>(_GetStatusSince_QNAME, GetStatusSince.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "getStatus")
    public JAXBElement<GetStatus> createGetStatus(GetStatus value) {
        return new JAXBElement<GetStatus>(_GetStatus_QNAME, GetStatus.class, null, value);
    }

}
