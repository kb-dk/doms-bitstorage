@javax.xml.bind.annotation.XmlSchema(namespace = "http://characterise.bitstorage.doms.statsbiblioteket.dk/")
package dk.statsbiblioteket.doms.bitstorage.characteriser;
