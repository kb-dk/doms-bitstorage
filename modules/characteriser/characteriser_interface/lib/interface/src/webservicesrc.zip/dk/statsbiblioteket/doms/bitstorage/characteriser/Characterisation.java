
package dk.statsbiblioteket.doms.bitstorage.characteriser;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for characterisation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="characterisation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="md5CheckSum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pronomID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="validationStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "characterisation", propOrder = {
    "md5CheckSum",
    "pronomID",
    "validationStatus"
})
public class Characterisation {

    @XmlElement(required = true)
    protected String md5CheckSum;
    @XmlElement(required = true)
    protected String pronomID;
    @XmlElement(required = true)
    protected String validationStatus;

    /**
     * Gets the value of the md5CheckSum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMd5CheckSum() {
        return md5CheckSum;
    }

    /**
     * Sets the value of the md5CheckSum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMd5CheckSum(String value) {
        this.md5CheckSum = value;
    }

    /**
     * Gets the value of the pronomID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPronomID() {
        return pronomID;
    }

    /**
     * Sets the value of the pronomID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPronomID(String value) {
        this.pronomID = value;
    }

    /**
     * Gets the value of the validationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationStatus() {
        return validationStatus;
    }

    /**
     * Sets the value of the validationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationStatus(String value) {
        this.validationStatus = value;
    }

}
