
package dk.statsbiblioteket.doms.bitstorage.lowlevel;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for disapprove complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="disapprove">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fileurl" type="{http://www.w3.org/2001/XMLSchema}anyURI"/>
 *         &lt;element name="md5string" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "disapprove", propOrder = {
    "fileurl",
    "md5String"
})
public class Disapprove {

    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected String fileurl;
    @XmlElement(name = "md5string", required = true)
    protected String md5String;

    /**
     * Gets the value of the fileurl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileurl() {
        return fileurl;
    }

    /**
     * Sets the value of the fileurl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileurl(String value) {
        this.fileurl = value;
    }

    /**
     * Gets the value of the md5String property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMd5String() {
        return md5String;
    }

    /**
     * Sets the value of the md5String property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMd5String(String value) {
        this.md5String = value;
    }

}
