@javax.xml.bind.annotation.XmlSchema(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/")
package dk.statsbiblioteket.doms.bitstorage.highlevel;
