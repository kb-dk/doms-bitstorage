
package dk.statsbiblioteket.doms.bitstorage.highlevel;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.bitstorage.highlevel package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeleteResponse_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "deleteResponse");
    private final static QName _InvalidFilenameException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "InvalidFilenameException");
    private final static QName _UploadFileToObjectResponse_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "uploadFileToObjectResponse");
    private final static QName _FileNotFoundException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "FileNotFoundException");
    private final static QName _Delete_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "delete");
    private final static QName _Publish_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "publish");
    private final static QName _ChecksumFailedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "ChecksumFailedException");
    private final static QName _UploadFileToObject_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "uploadFileToObject");
    private final static QName _FileAlreadyApprovedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "FileAlreadyApprovedException");
    private final static QName _PublishResponse_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "publishResponse");
    private final static QName _Status_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "status");
    private final static QName _StatusResponse_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "statusResponse");
    private final static QName _CommunicationException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "CommunicationException");
    private final static QName _UploadFailedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "UploadFailedException");
    private final static QName _NotEnoughFreeSpaceException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "NotEnoughFreeSpaceException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.bitstorage.highlevel
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Event }
     * 
     */
    public Event createEvent() {
        return new Event();
    }

    /**
     * Create an instance of {@link UploadFileToObjectResponse }
     * 
     */
    public UploadFileToObjectResponse createUploadFileToObjectResponse() {
        return new UploadFileToObjectResponse();
    }

    /**
     * Create an instance of {@link DeleteResponse }
     * 
     */
    public DeleteResponse createDeleteResponse() {
        return new DeleteResponse();
    }

    /**
     * Create an instance of {@link Status }
     * 
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link StatusResponse }
     * 
     */
    public StatusResponse createStatusResponse() {
        return new StatusResponse();
    }

    /**
     * Create an instance of {@link Delete }
     * 
     */
    public Delete createDelete() {
        return new Delete();
    }

    /**
     * Create an instance of {@link Operation }
     * 
     */
    public Operation createOperation() {
        return new Operation();
    }

    /**
     * Create an instance of {@link StatusInformation }
     * 
     */
    public StatusInformation createStatusInformation() {
        return new StatusInformation();
    }

    /**
     * Create an instance of {@link Publish }
     * 
     */
    public Publish createPublish() {
        return new Publish();
    }

    /**
     * Create an instance of {@link UploadFileToObject }
     * 
     */
    public UploadFileToObject createUploadFileToObject() {
        return new UploadFileToObject();
    }

    /**
     * Create an instance of {@link PublishResponse }
     * 
     */
    public PublishResponse createPublishResponse() {
        return new PublishResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "deleteResponse")
    public JAXBElement<DeleteResponse> createDeleteResponse(DeleteResponse value) {
        return new JAXBElement<DeleteResponse>(_DeleteResponse_QNAME, DeleteResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "InvalidFilenameException")
    public JAXBElement<String> createInvalidFilenameException(String value) {
        return new JAXBElement<String>(_InvalidFilenameException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadFileToObjectResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "uploadFileToObjectResponse")
    public JAXBElement<UploadFileToObjectResponse> createUploadFileToObjectResponse(UploadFileToObjectResponse value) {
        return new JAXBElement<UploadFileToObjectResponse>(_UploadFileToObjectResponse_QNAME, UploadFileToObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileNotFoundException")
    public JAXBElement<String> createFileNotFoundException(String value) {
        return new JAXBElement<String>(_FileNotFoundException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Delete }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "delete")
    public JAXBElement<Delete> createDelete(Delete value) {
        return new JAXBElement<Delete>(_Delete_QNAME, Delete.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Publish }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "publish")
    public JAXBElement<Publish> createPublish(Publish value) {
        return new JAXBElement<Publish>(_Publish_QNAME, Publish.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "ChecksumFailedException")
    public JAXBElement<String> createChecksumFailedException(String value) {
        return new JAXBElement<String>(_ChecksumFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadFileToObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "uploadFileToObject")
    public JAXBElement<UploadFileToObject> createUploadFileToObject(UploadFileToObject value) {
        return new JAXBElement<UploadFileToObject>(_UploadFileToObject_QNAME, UploadFileToObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileAlreadyApprovedException")
    public JAXBElement<String> createFileAlreadyApprovedException(String value) {
        return new JAXBElement<String>(_FileAlreadyApprovedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublishResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "publishResponse")
    public JAXBElement<PublishResponse> createPublishResponse(PublishResponse value) {
        return new JAXBElement<PublishResponse>(_PublishResponse_QNAME, PublishResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Status }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "status")
    public JAXBElement<Status> createStatus(Status value) {
        return new JAXBElement<Status>(_Status_QNAME, Status.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "statusResponse")
    public JAXBElement<StatusResponse> createStatusResponse(StatusResponse value) {
        return new JAXBElement<StatusResponse>(_StatusResponse_QNAME, StatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "CommunicationException")
    public JAXBElement<String> createCommunicationException(String value) {
        return new JAXBElement<String>(_CommunicationException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "UploadFailedException")
    public JAXBElement<String> createUploadFailedException(String value) {
        return new JAXBElement<String>(_UploadFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "NotEnoughFreeSpaceException")
    public JAXBElement<String> createNotEnoughFreeSpaceException(String value) {
        return new JAXBElement<String>(_NotEnoughFreeSpaceException_QNAME, String.class, null, value);
    }

}
