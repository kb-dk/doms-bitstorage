
package dk.statsbiblioteket.doms.bitstorage.highlevel;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for uploadFileToObject complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="uploadFileToObject">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pid" type="{http://highlevel.bitstorage.doms.statsbiblioteket.dk/}fedoraPid"/>
 *         &lt;element name="filename" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="filedata" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/>
 *         &lt;element name="md5string" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="filelength" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "uploadFileToObject", propOrder = {
    "pid",
    "filename",
    "filedata",
    "md5String",
    "filelength"
})
public class UploadFileToObject {

    @XmlElement(required = true)
    protected String pid;
    @XmlElement(required = true)
    protected String filename;
    @XmlElement(required = true)
    @XmlMimeType("application/octet-stream")
    protected DataHandler filedata;
    @XmlElement(name = "md5string", required = true)
    protected String md5String;
    protected long filelength;

    /**
     * Gets the value of the pid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPid() {
        return pid;
    }

    /**
     * Sets the value of the pid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPid(String value) {
        this.pid = value;
    }

    /**
     * Gets the value of the filename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilename() {
        return filename;
    }

    /**
     * Sets the value of the filename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilename(String value) {
        this.filename = value;
    }

    /**
     * Gets the value of the filedata property.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getFiledata() {
        return filedata;
    }

    /**
     * Sets the value of the filedata property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setFiledata(DataHandler value) {
        this.filedata = value;
    }

    /**
     * Gets the value of the md5String property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMd5String() {
        return md5String;
    }

    /**
     * Sets the value of the md5String property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMd5String(String value) {
        this.md5String = value;
    }

    /**
     * Gets the value of the filelength property.
     * 
     */
    public long getFilelength() {
        return filelength;
    }

    /**
     * Sets the value of the filelength property.
     * 
     */
    public void setFilelength(long value) {
        this.filelength = value;
    }

}
