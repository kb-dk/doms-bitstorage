
package dk.statsbiblioteket.doms.bitstorage.highlevel;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for operation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="operation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fedoraPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fedoraDatastream" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fileSize" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="highlevelMethod">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="upload"/>
 *               &lt;enumeration value="approve"/>
 *               &lt;enumeration value="delete"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="history" type="{http://highlevel.bitstorage.doms.statsbiblioteket.dk/}event" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "operation", propOrder = {
    "id",
    "fedoraPid",
    "fedoraDatastream",
    "fileSize",
    "highlevelMethod",
    "history"
})
public class Operation {

    @XmlElement(name = "ID", required = true)
    protected String id;
    @XmlElement(required = true)
    protected String fedoraPid;
    @XmlElement(required = true)
    protected String fedoraDatastream;
    protected Long fileSize;
    @XmlElement(required = true)
    protected String highlevelMethod;
    protected List<Event> history;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the fedoraPid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFedoraPid() {
        return fedoraPid;
    }

    /**
     * Sets the value of the fedoraPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFedoraPid(String value) {
        this.fedoraPid = value;
    }

    /**
     * Gets the value of the fedoraDatastream property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFedoraDatastream() {
        return fedoraDatastream;
    }

    /**
     * Sets the value of the fedoraDatastream property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFedoraDatastream(String value) {
        this.fedoraDatastream = value;
    }

    /**
     * Gets the value of the fileSize property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getFileSize() {
        return fileSize;
    }

    /**
     * Sets the value of the fileSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setFileSize(Long value) {
        this.fileSize = value;
    }

    /**
     * Gets the value of the highlevelMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHighlevelMethod() {
        return highlevelMethod;
    }

    /**
     * Sets the value of the highlevelMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHighlevelMethod(String value) {
        this.highlevelMethod = value;
    }

    /**
     * Gets the value of the history property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the history property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Event }
     * 
     * 
     */
    public List<Event> getHistory() {
        if (history == null) {
            history = new ArrayList<Event>();
        }
        return this.history;
    }

}
