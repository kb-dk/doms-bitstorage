
package dk.statsbiblioteket.doms.bitstorage.lowlevel;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.bitstorage.lowlevel package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Spaceleft_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "spaceleft");
    private final static QName _NotEnoughFreeSpaceException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "NotEnoughFreeSpaceException");
    private final static QName _UploadFailedException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "UploadFailedException");
    private final static QName _GetMd5_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "getMd5");
    private final static QName _CommunicationException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "CommunicationException");
    private final static QName _Disapprove_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "disapprove");
    private final static QName _FileAlreadyApprovedException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "FileAlreadyApprovedException");
    private final static QName _Approve_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "approve");
    private final static QName _GetMaxFileSize_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "getMaxFileSize");
    private final static QName _IsApprovedResponse_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "isApprovedResponse");
    private final static QName _GetMaxFileSizeResponse_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "getMaxFileSizeResponse");
    private final static QName _ChecksumFailedException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "ChecksumFailedException");
    private final static QName _IsApproved_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "isApproved");
    private final static QName _FileNotFoundException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "FileNotFoundException");
    private final static QName _GetMd5Response_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "getMd5Response");
    private final static QName _InvalidFilenameException_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "InvalidFilenameException");
    private final static QName _ApproveResponse_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "approveResponse");
    private final static QName _SpaceleftResponse_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "spaceleftResponse");
    private final static QName _UploadFileResponse_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "uploadFileResponse");
    private final static QName _UploadFile_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "uploadFile");
    private final static QName _DisapproveResponse_QNAME = new QName("http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", "disapproveResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.bitstorage.lowlevel
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetMaxFileSizeResponse }
     * 
     */
    public GetMaxFileSizeResponse createGetMaxFileSizeResponse() {
        return new GetMaxFileSizeResponse();
    }

    /**
     * Create an instance of {@link Spaceleft }
     * 
     */
    public Spaceleft createSpaceleft() {
        return new Spaceleft();
    }

    /**
     * Create an instance of {@link Approve }
     * 
     */
    public Approve createApprove() {
        return new Approve();
    }

    /**
     * Create an instance of {@link GetMaxFileSize }
     * 
     */
    public GetMaxFileSize createGetMaxFileSize() {
        return new GetMaxFileSize();
    }

    /**
     * Create an instance of {@link GetMd5 }
     * 
     */
    public GetMd5 createGetMd5() {
        return new GetMd5();
    }

    /**
     * Create an instance of {@link ApproveResponse }
     * 
     */
    public ApproveResponse createApproveResponse() {
        return new ApproveResponse();
    }

    /**
     * Create an instance of {@link UploadFile }
     * 
     */
    public UploadFile createUploadFile() {
        return new UploadFile();
    }

    /**
     * Create an instance of {@link DisapproveResponse }
     * 
     */
    public DisapproveResponse createDisapproveResponse() {
        return new DisapproveResponse();
    }

    /**
     * Create an instance of {@link GetMd5Response }
     * 
     */
    public GetMd5Response createGetMd5Response() {
        return new GetMd5Response();
    }

    /**
     * Create an instance of {@link IsApprovedResponse }
     * 
     */
    public IsApprovedResponse createIsApprovedResponse() {
        return new IsApprovedResponse();
    }

    /**
     * Create an instance of {@link SpaceleftResponse }
     * 
     */
    public SpaceleftResponse createSpaceleftResponse() {
        return new SpaceleftResponse();
    }

    /**
     * Create an instance of {@link IsApproved }
     * 
     */
    public IsApproved createIsApproved() {
        return new IsApproved();
    }

    /**
     * Create an instance of {@link Disapprove }
     * 
     */
    public Disapprove createDisapprove() {
        return new Disapprove();
    }

    /**
     * Create an instance of {@link UploadFileResponse }
     * 
     */
    public UploadFileResponse createUploadFileResponse() {
        return new UploadFileResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Spaceleft }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "spaceleft")
    public JAXBElement<Spaceleft> createSpaceleft(Spaceleft value) {
        return new JAXBElement<Spaceleft>(_Spaceleft_QNAME, Spaceleft.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "NotEnoughFreeSpaceException")
    public JAXBElement<String> createNotEnoughFreeSpaceException(String value) {
        return new JAXBElement<String>(_NotEnoughFreeSpaceException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "UploadFailedException")
    public JAXBElement<String> createUploadFailedException(String value) {
        return new JAXBElement<String>(_UploadFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMd5 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "getMd5")
    public JAXBElement<GetMd5> createGetMd5(GetMd5 value) {
        return new JAXBElement<GetMd5>(_GetMd5_QNAME, GetMd5 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "CommunicationException")
    public JAXBElement<String> createCommunicationException(String value) {
        return new JAXBElement<String>(_CommunicationException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Disapprove }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "disapprove")
    public JAXBElement<Disapprove> createDisapprove(Disapprove value) {
        return new JAXBElement<Disapprove>(_Disapprove_QNAME, Disapprove.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileAlreadyApprovedException")
    public JAXBElement<String> createFileAlreadyApprovedException(String value) {
        return new JAXBElement<String>(_FileAlreadyApprovedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Approve }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "approve")
    public JAXBElement<Approve> createApprove(Approve value) {
        return new JAXBElement<Approve>(_Approve_QNAME, Approve.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMaxFileSize }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "getMaxFileSize")
    public JAXBElement<GetMaxFileSize> createGetMaxFileSize(GetMaxFileSize value) {
        return new JAXBElement<GetMaxFileSize>(_GetMaxFileSize_QNAME, GetMaxFileSize.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsApprovedResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "isApprovedResponse")
    public JAXBElement<IsApprovedResponse> createIsApprovedResponse(IsApprovedResponse value) {
        return new JAXBElement<IsApprovedResponse>(_IsApprovedResponse_QNAME, IsApprovedResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMaxFileSizeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "getMaxFileSizeResponse")
    public JAXBElement<GetMaxFileSizeResponse> createGetMaxFileSizeResponse(GetMaxFileSizeResponse value) {
        return new JAXBElement<GetMaxFileSizeResponse>(_GetMaxFileSizeResponse_QNAME, GetMaxFileSizeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "ChecksumFailedException")
    public JAXBElement<String> createChecksumFailedException(String value) {
        return new JAXBElement<String>(_ChecksumFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsApproved }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "isApproved")
    public JAXBElement<IsApproved> createIsApproved(IsApproved value) {
        return new JAXBElement<IsApproved>(_IsApproved_QNAME, IsApproved.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileNotFoundException")
    public JAXBElement<String> createFileNotFoundException(String value) {
        return new JAXBElement<String>(_FileNotFoundException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMd5Response }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "getMd5Response")
    public JAXBElement<GetMd5Response> createGetMd5Response(GetMd5Response value) {
        return new JAXBElement<GetMd5Response>(_GetMd5Response_QNAME, GetMd5Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "InvalidFilenameException")
    public JAXBElement<String> createInvalidFilenameException(String value) {
        return new JAXBElement<String>(_InvalidFilenameException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApproveResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "approveResponse")
    public JAXBElement<ApproveResponse> createApproveResponse(ApproveResponse value) {
        return new JAXBElement<ApproveResponse>(_ApproveResponse_QNAME, ApproveResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SpaceleftResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "spaceleftResponse")
    public JAXBElement<SpaceleftResponse> createSpaceleftResponse(SpaceleftResponse value) {
        return new JAXBElement<SpaceleftResponse>(_SpaceleftResponse_QNAME, SpaceleftResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadFileResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "uploadFileResponse")
    public JAXBElement<UploadFileResponse> createUploadFileResponse(UploadFileResponse value) {
        return new JAXBElement<UploadFileResponse>(_UploadFileResponse_QNAME, UploadFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadFile }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "uploadFile")
    public JAXBElement<UploadFile> createUploadFile(UploadFile value) {
        return new JAXBElement<UploadFile>(_UploadFile_QNAME, UploadFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DisapproveResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://lowlevel.bitstorage.doms.statsbiblioteket.dk/", name = "disapproveResponse")
    public JAXBElement<DisapproveResponse> createDisapproveResponse(DisapproveResponse value) {
        return new JAXBElement<DisapproveResponse>(_DisapproveResponse_QNAME, DisapproveResponse.class, null, value);
    }

}
