package dk.statsbiblioteket.doms.template;

public class PIDGeneratorException extends RuntimeException {
    public PIDGeneratorException(String message, Exception cause) {
        super(message, cause);
    }
}
