package dk.statsbiblioteket.doms.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: abr
 * Date: Nov 12, 2008
 * Time: 8:53:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidUserException extends Exception {

}
